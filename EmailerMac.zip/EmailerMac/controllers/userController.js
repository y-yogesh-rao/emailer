const getLoginData = async (userId,roleId) => {
    let Permissions=[];
    let userProfile = {};
    let userRolePermissions={};
    userProfile = await Models.UserProfile.findOne({attributes:["firstName","lastName","attachmentId","gender","dob"],where:{userId},include:[{attributes:['uniqueName','path'],model:Models.Attachment}]});
    userRolePermissions =  await Models.Role.findOne({attributes:["id","name"],where:{id:roleId},include:[{attributes:["permissionCode"],model:Models.Permission,required:false}]});
    if(userRolePermissions) {
        Permissions.push(userRolePermissions.name.replace(/ /g,'-').toLowerCase());
        for(let permission of userRolePermissions?.Permissions) Permissions.push(permission.permissionCode)
    }

    return {UserProfile:userProfile,Role:userRolePermissions.Role,Permissions:Permissions};
}

const loginAction = async (user) => {
    let hasFullAccess = 0;
    if(user.roleId === 1) hasFullAccess = 1;
    let userData = await getLoginData(user.id,user.roleId);
    let responseData = {User:user,UserProfile:userData.UserProfile,Role:userData.Role,Permissions:userData.Permissions,hasAllAccess:hasFullAccess}
    const tokenData = responseData;
    let token = Common.signToken(tokenData);
    _.assign(responseData,{token:token});
    return responseData;
}

exports.getUserDetails = async (req,h) => {
    try {
        const userId = req.auth.credentials.userData.User.id;
        const userExists = await Models.User.findOne({
            where:{id:userId},
            include:[{model:Models.Role,attributes:['id','name']}],
            attributes:["id","email","status","roleId","accountId","phoneNumber"],
        });

        let responseData = userExists ? await loginAction(userExists) : null;
        return h.response({success:true,message:req.i18n.__('REQUEST_SUCCESSFUL'),responseData:responseData}).code(200);
    } catch (error) {
        console.log(error);
        return h.response({success:false,message:req.i18n.__('SOMETHING_WENT_WRONG'),responseData:{}}).code(500);
    }
}

exports.signup = async (req,h) => {
    const transaction = await Models.sequelize.transaction();
    try {
        let languageCode = req.headers.language;
        let languageId = LanguageIds[LanguageCodes.indexOf(req.headers.language)];

        let {email,password,confirmPassword,phoneNumber,countryCode,firstName,lastName,dob,gender} = req.payload;

        if(password !== confirmPassword) {
            await transaction.rollback();
            return h.response({success:false,message:req.i18n.__('PASSWORD_AND_CONFIRM_PASSWORD_DOESNT_MATCH'),responseData:{}}).code(400);
        }

        let VerifyEmail = await Models.User.findOne({where:{email}});
        console.log('******', VerifyEmail);
        let type='signup';
        if(!VerifyEmail) {
            let emailTemplate = await Models.EmailTemplate.findOne({
                where:{code:"SIGNUP_PROCESS"},
                include:[
                    {
                        model:Models.EmailTemplateContent,
                        where:{languageId},
                        required: false
                    },{
                        model:Models.EmailTemplateContent,
                        as:"defaultContent",
                        where:{languageId:process.env.DEFAULT_LANGUANGE_CODE_ID},
                        required: false,
                    }
                ]
            });
            
            if(emailTemplate){
                token = Common.signToken({email,type,password,phoneNumber,countryCode,firstName,lastName,dob,gender});
                // code = Common.generateCode(4);
                code = '9999';

                await Models.Token.upsert({email,token,type,code,status:Constants.STATUS.ACTIVE},{where:{email,type},transaction:transaction});

                let emailContent = emailTemplate.EmailTemplateContents.length > 0 ? emailTemplate.EmailTemplateContents[0].content : emailTemplate.defaultContent[0].content;
                let subject = emailTemplate.EmailTemplateContents.length > 0 ? emailTemplate.EmailTemplateContents[0].subject : emailTemplate.defaultContent[0].subject;
                let replacement = { token:token, code:code, domain:`${process.env.DOMAIN}:${process.env.NODE_PORT}/user/verifyEmail/token=` };

                await Common.sendEmail([email],[process.env.FROM_EMAIL],[],[],subject,emailContent,replacement,[],languageCode,'default');

                await transaction.commit();
                return h.response({success:true,message:req.i18n.__('VERIFICATION_EMAIL_SENT_SUCCESSFULLY'),responseData:{token}}).code(200);
            } else {
                await transaction.rollback();
                return h.response({success:false,message:req.i18n.__('ERROR_WHILE_SENDING_EMAIL'),responseData:{}}).code(400);
            }
        } else {
            await transaction.rollback();
            return h.response({success:false,message:req.i18n.__('EMAIL_ALREADY_IN_USE'),responseData:{}}).code(400);
        }
    } catch (error) {
        console.log(error);
        await transaction.rollback();
        return h.response({success:false,message:req.i18n.__('SOMETHING_WENT_WRONG'),responseData:{}}).code(500);
    }  
}

exports.verifyCode = async (req,h) => {
    const transaction = await Models.sequelize.transaction();
    try{
        let languageId = LanguageIds[LanguageCodes.indexOf(req.headers.language)];
        let languageCode = req.headers.language;

        let code = req.payload.code;
        let token = req.payload.token;
        let verificationType = req.payload.verificationType;

        let verifyToken = await Models.Token.findOne({where:{token:token,code:code,status:Constants.STATUS.ACTIVE}});
        if (verifyToken) {
            let tokenData = await Common.validateToken(Jwt.decode(token));
            let userData = tokenData.credentials.userData;
            console.log('User data: ', userData);
            switch (verificationType) {
                case 'signup':
                    const rounds = parseInt(process.env.HASH_ROUNDS);
                    let userPassword = Bcrypt.hashSync(userData.password,rounds);
                    const userRole = await Models.Role.findOne({where:{name:'User'}});
                    let email = userData.email;

                    const doExists = await  Models.User.findOne({where:{
                        [Op.or]: [
                            {email:userData.email},
                            {phoneNumber:userData.phoneNumber},
                        ]
                    }})
                    if(doExists) {
                        await transaction.rollback();
                        return h.response({success:false,message:req.i18n.__("EMAIL_OR_PHONE_NUMBER_IS_ALREADY_IN_USE"),responseData:{}}).code(400);
                    }

                    let newUser = await Models.User.create({
                        roleId:userRole.id,
                        email:userData.email,
                        password:userPassword,
                        countryCode:userData.countryCode,
                        phoneNumber:userData.phoneNumber,
                        status:Constants.STATUS.ACTIVE,
                        UserProfile:{
                            gender:userData.gender,
                            lastName:userData.lastName,
                            firstName:userData.firstName,
                            dob:Moment(userData.dob,'YYYY-MM-DD'),
                        }
                    },{include:{model:Models.UserProfile},transaction:transaction});
                    if (newUser) {
                        let pass = "*".repeat(userData.password.length);
                        newUser.dataValues.password = pass;
                        await verifyToken.update({status:Constants.STATUS.INACTIVE,userId:newUser.id},{transaction:transaction});
                        responseData = await loginAction(newUser);

                        //send email to user
                        let emailTemplate = await Models.EmailTemplate.findOne({
                            where:{code:"SIGNUP_SUCCESS"},
                            include:[
                                {
                                    model:Models.EmailTemplateContent,
                                    where:{languageId},
                                    required: false
                                },{
                                    model:Models.EmailTemplateContent,
                                    as:"defaultContent",
                                    where:{languageId:process.env.DEFAULT_LANGUANGE_CODE_ID},
                                    required: false,
                                }
                            ]
                        });
                          
                        let emailContent= emailTemplate.EmailTemplateContents.length>0 ? emailTemplate.EmailTemplateContents[0].content : emailTemplate.defaultContent[0].content;
                        let subject = emailTemplate.EmailTemplateContents.length>0 ? emailTemplate.EmailTemplateContents[0].subject : emailTemplate.defaultContent[0].subject;

                        let replacement = { domain:`${process.env.DOMAIN}:${process.env.NODE_PORT}` };
                        await Common.sendEmail([email],[process.env.FROM_EMAIL],[],[],subject,emailContent,replacement,[],languageCode,'default');

                        await transaction.commit();
                        return h.response({success:true,message:req.i18n.__("USER_VERIFIED_SUCCESSFULLY"),responseData}).code(200);
                    } else {
                        await transaction.rollback();
                        return h.response({success:false,message:req.i18n.__("ERROR_WHILE_CREATING_THE_USER"),responseData:{}}).code(400);
                    }

                case 'resetPassword':
                    let token = req.payload.token;
                    let code = req.payload.code;
                    //let verifyToken = await Models.Token.findOne({where:{token:token,code:code,status:Constants.STATUS.ACTIVE}});
                    let tokenData = await Common.validateToken(Jwt.decode(token));
                    if(verifyToken){
                        let existingAccount={};
                        if(tokenData.isValid){
                            existingAccount = await Models.User.findOne({where:{email:tokenData.credentials.userData.email}});
                            if(existingAccount){
                                // verifyToken.update({status:Constants.STATUS.INACTIVE,user_id:tokenData.credentials.userData.user_id});
                                responseData={token}
                                await transaction.commit();
                                return h.response({success:false,message: req.i18n.__("RESET_PASSWORD_VERIFICATION_SUCCESSFUL"),responseData:responseData}).code(200);
                            } else {
                                await transaction.rollback();
                                return h.response({success:false,message:req.i18n.__('ACCOUNT_DOESNT_EXISTS'),responseData:{}}).code(400);
                            }
                        } else {
                            await transaction.rollback();
                            return h.response({success:false,message:req.i18n.__('INVALID_OR_EXPIRED_TOKEN'),responseData:{}}).code(400);
                        }
                    } else {
                        await transaction.rollback();
                        return h.response({success:false,message:req.i18n.__('INVALID_OR_EXPIRED_TOKEN'),responseData:{}}).code(400);
                    }

                default:
                    await transaction.rollback();
                    return h.response({success:false,message:req.i18n.__("INVALID_REQUEST"),responseData:{}}).code(400);
            }
        } else {
            await transaction.rollback();
            return h.response({success:false,message:req.i18n.__("EXPIRED_OR_INVALID_TOKEN"),responseData:{}}).code(400);
        }
    } catch(error) {
        console.log(error)
        await transaction.rollback();
        return h.response({success:false,message:req.i18n.__("SOMETHING_WENT_WRONG"),responseData:{}}).code(500);
    }
}

exports.login = async (req,h) => {
    try{
        let user=null;
        let newUser={};
        let userExists ={};
        let userProfile={};
        let responseData={};
        let passwordVerification='';
        switch(req.payload.type) {
            case 'email-password':
                user=await Models.User.findOne({
                    where:{email:req.payload.username},
                    include:[{model:Models.Role,attributes:['id','name']}],
                    attributes:["id","email","status","password","roleId","accountId","phoneNumber"],
                });
                if (user) {
                    if (user.status === Constants.STATUS.INACTIVE) {
                        return h.response({success:false,message:req.i18n.__("PROFILE_BLOCKED_BY_ADMIN"),responseData:{}}).code(400);
                    } else {
                        passwordVerification = Bcrypt.compareSync(req.payload.password,user.password);
                        if (passwordVerification) {
                            user.dataValues.password = "*".repeat(req.payload.password.length);
                            responseData = await loginAction(user);
                            return h.response({success:true,message:req.i18n.__("AUTHROIZATION_VALIDATED_SUCCESSFULLY"),responseData:responseData}).code(200);
                        } else return h.response({success:false,message:req.i18n.__("INVALID_EMAIL_OR_PASSWORD"),responseData:{}}).code(403);
                    }
                } else return h.response({success:false,message:req.i18n.__("USER_DOES_NOT_EXISTS"),responseData:{}}).code(403);
            case 'username-password':
                user=await Models.User.findOne({where:{username:req.payload.username}});
                if(user) {
                    passwordVerification = Bcrypt.compareSync(req.payload.password,user.password);
                    if (passwordVerification) {
                        user.dataValues.password = "*".repeat(req.payload.password.length);
                        responseData = await loginAction(user);
                        return h.response({success:true,message:req.i18n.__("AUTHROIZATION_VALIDATED_SUCCESSFULLY"),responseData:responseData}).code(200);
                    } else return h.response({success:false,message:req.i18n.__("INCORRECT_PASSWORD"),responseData:{}}).code(403);
                } else return h.response({success:false,message:req.i18n.__("INVALID_USERNAME"),responseData:{}}).code(403);
            case 'mobile-otp':
                user=await Models.User.findOne({where:{mobile:req.payload.username}});
                sendOTP=Common.verifyOTP(req.payload.username);
                if (sendOTP.pinId) {
                    return h.response({
                        responseData: {mobile:req.payload.username,pinId:sendOTP.pinId},
                        message: req.i18n.__("OTP_SENT_SUCCESSFULLY")
                    });
                } else {
                    return Common.generateError(req,400,'ERROR_WHILE_SENDING_OTP',{}); 
                }
            case 'social-login':
                token = request.payload.socialToken;
                platform = request.payload.socialPlatform;
                let verification = await verifySocialLogin(platform,accessToken);
                if(verification){
                    userExists = await Models.User.findOne({where:{[Op.or]:[{email:req.payload.username},{mobile:req.payload.username}]}});
                    if(userExists){
                        responseData = await loginAction(user);
                        return h.response({
                            responseData:responseData,
                            message: req.i18n.__("AUTHORIZATION_VALIDATED_SUCCESSFULLY")
                        });
                    }else{
                        const transaction = await Models.sequelize.transaction(); 
                        try{
                            switch(socialWithMobile){
                                case 0:
                                    userProfile={firstName:req.payload.firstName,lastName:req.payload.lastName};
                                    newUser=await Models.User.create({email:req.payload.username,UserProfile:userProfile},{include:[{model:Models.UserProfile}],transaction:transaction});
                                    if(newUser){
                                        await transaction.commit();
                                        responseData = await loginAction(newUser);
                                        return h.response({
                                            responseData:responseData,
                                            message: req.i18n.__("AUTHORIZATION_VALIDATED_SUCCESSFULLY")
                                        });
                                    }else{
                                        await transaction.rollback();
                                        return Common.generateError(req,400,'ERROR_WHILE_CREATING_ACCOUNT_FOR_SOCIAL_LOGIN',{});
                                    }
                                    break;
                                case 1:
                                    userProfile={firstName:req.payload.firstName,lastName:req.payload.lastName};
                                    newUser=await Models.User.create({mobile:req.payload.username,UserProfile:userProfile},{include:[{model:Models.UserProfile}],transaction:transaction});
                                    if(newUser){
                                        await transaction.commit();
                                        responseData = await loginAction(newUser);
                                        return h.response({
                                            responseData:responseData,
                                            message: req.i18n.__("AUTHORIZATION_VALIDATED_SUCCESSFULLY")
                                        });
                                    }else{
                                        await transaction.rollback();
                                        return Common.generateError(req,400,'ERROR_WHILE_CREATING_ACCOUNT_FOR_SOCIAL_LOGIN',{});
                                    }
                                    break;

                                default: 
                                    return Common.generateError(req,400,'AUTHORIZATION_FAILED',{}); 
                                    break;
                            }
                        }catch(err){
                            await transaction.rollback();
                            return Common.generateError(req,500,'EXCEPTION_WHILE_CREATING_ACCOUNT_FOR_SOCIAL_LOGIN',{});
                        }
                    }
                }else{
                    return Common.generateError(req,400,'TOKEN_VERIFICATION_FAILED',{});
                }
                break;
            
            default:
                return Common.generateError(req,400,'LOGIN_METHOD_NOT_SUPPORTED',{});
        }
    } catch (error) {
        console.log(error);
        return h.response({success:false,message:req.i18n.__('SOMETHING_WENT_WRONG'),responseData:{}}).code(500);
    }
}
