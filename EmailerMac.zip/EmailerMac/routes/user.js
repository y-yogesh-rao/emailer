"use strict";
const Joi = require("joi");
const userController = require("../controllers/userController");

module.exports = [
	{
		method : "GET",
		path : "/admin/getUserDetails",
		handler : userController.getUserDetails,
		options: {
			tags: ["api", "User"],
			notes: "Endpoint to get user details",
			description: "Get User Details",
			auth: {strategy:'jwt'},
			validate: {
				headers: Joi.object(Common.headers(true)).options({
					allowUnknown: true
				}),
				options: {
					abortEarly: false
				},
				query:{
				},
				failAction: async (req, h, err) => {
					return Common.FailureError(err, req);
				},
				validator: Joi
			},
			pre : [{method: Common.prefunction}]
		}
	},
	{
		method : "POST",
		path : "/user/signup",
		handler : userController.signup,
		options: {
			tags: ["api", "User"],
			notes: "Endpoint to register a new user",
			description: "User Signup",
			auth: false,
			validate: {
				headers: Joi.object(Common.headers()).options({
					allowUnknown: true
				}),
				options: {
					abortEarly: false
				},
				payload:{
					dob: Joi.string().max(50).optional().default(null),
					gender: Joi.string().max(20).optional().default(null),
					lastName: Joi.string().max(250).optional().default(null),
					countryCode: Joi.string().max(10).optional().default('+91'),
					phoneNumber: Joi.string().min(5).max(15).optional().default(null),
					email: Joi.string().email().required().error(errors=>{return Common.routeError(errors,'EMAIL_IS_REQUIRED')}),
					password: Joi.string().required().min(8).error(errors=>{return Common.routeError(errors,'PASSWORD_IS_REQUIRED')}),
					firstName: Joi.string().max(250).required().error(errors=>{return Common.routeError(errors,'FIRST_NAME_IS_REQUIRED')}),
					confirmPassword: Joi.string().required().min(8).error(errors=>{return Common.routeError(errors,'CONFIRM_PASSWORD_IS_REQUIRED')})
				},
				failAction: async (req, h, err) => {
					return Common.FailureError(err, req);
				},
				validator: Joi
			},
			pre : [{method: Common.prefunction}]
		}
	},
	{
		method : "POST",
		path : "/user/verifyCode",
		handler : userController.verifyCode,
		options: {
			tags: ["api", "User"],
			notes: "Endpoint to verify code",
			description: "Code verification",
			auth: false,
			validate: {
				headers: Joi.object(Common.headers()).options({
					allowUnknown: true
				}),
				options: {
					abortEarly: false
				},
				payload:{
					token:Joi.string().required().error(errors=>{return Common.routeError(errors,'TOKEN_IS_REQUIRED')}),
					code:Joi.string().required().error(errors=>{return Common.routeError(errors,'CODE_IS_REQUIRED')}),
					verificationType:Joi.string().required().valid('signup','resetPassword').error(errors=>{return Common.routeError(errors,'VERIFICATION_TYPE_IS_REQUIRED')}),
				},
				failAction: async (req, h, err) => {
					return Common.FailureError(err, req);
				},
				validator: Joi
			},
			pre : [{method: Common.prefunction}]
		}
	},
    {
		method : "POST",
		path : "/user/login",
		handler : userController.login,
		options: {
			tags: ["api", "User"],
			notes: "Endpoint to allow user to login to portal with email, mobile or social login options",
			description: "User login",
			auth: false,
			validate: {
				headers: Joi.object(Common.headers()).options({
					allowUnknown: true
				}),
				options: {
					abortEarly: false
				},
				payload: {
                    deviceFlag : Joi.string().valid('WEB','APP').optional().default('APP'),
                    username:Joi.string().required().error(errors=>{return Common.routeError(errors,'EMAIL_IS_REQUIRED')}),
                    type : Joi.string().valid('email-password','username-password','mobile-otp','social-login').required().default('email-password'),
                    password:Joi.when('type', {
                        switch: [
                            { is: 'email-password', then: Joi.required().error(errors=>{return Common.routeError(errors,'PASSWORD_IS_REQUIRED')})},
                            { is: 'username-password', then: Joi.required().error(errors=>{return Common.routeError(errors,'PASSWORD_IS_REQUIRED')})}
                        ],
                        otherwise: Joi.optional()
                    }),
                    socialPlatform:Joi.when('type', {
                        switch: [
                            { is: 'social-login', then: Joi.required().default('facebook').valid('google','facebook') }
                        ],
                        otherwise: Joi.optional()
                    }),
					socialWithMobile:Joi.when('type', {
                        switch: [
                            { is: 'social-login', then: Joi.required().valid(0,1) }
                        ],
                        otherwise: Joi.optional().default(0)
                    }),
				},
				failAction: async (req, h, err) => {
					return Common.FailureError(err, req);
				},
				validator: Joi
			},
			pre : [{method: Common.prefunction}]
		}
	}
]