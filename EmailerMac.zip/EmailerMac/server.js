// Include required libraries and make them globally accessible
console.log("server setup initialized....")
require("./packages");
console.log("Initializing server...");
require("./startServer");
console.log("server initialized");
init();
